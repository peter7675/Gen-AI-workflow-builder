
import chromadb
import os

# Create data directory if it doesn't exist
persist_directory = os.path.join(os.getcwd(), "chroma_db")
if not os.path.exists(persist_directory):
    os.makedirs(persist_directory)

_chroma_client = chromadb.PersistentClient(path=persist_directory)

print(f"ChromaDB: Initialized persistent client at {persist_directory}")

def get_chroma_collection(collection_name: str):
    """
    Retrieves or creates a ChromaDB collection by name.

    Args:
        collection_name (str): The name of the collection to retrieve or create.

    Returns:
        chromadb.api.models.Collection.Collection: The ChromaDB collection object.
    """
    if not collection_name:
        raise ValueError("Collection name cannot be empty.")
    
    try:
        collection = _chroma_client.get_or_create_collection(name=collection_name)
        print(f"ChromaDB: Accessed/Created collection '{collection_name}'.")
        return collection
    except Exception as e:
        print(f"ChromaDB: Failed to access collection '{collection_name}': {e}")
        raise