-- Create a private schema for extensions
CREATE SCHEMA IF NOT EXISTS extensions;

-- Enable Extensions in the extensions schema
CREATE EXTENSION IF NOT EXISTS vector SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" SCHEMA extensions;

-- Ensure public schema can use extensions
GRANT USAGE ON SCHEMA extensions TO public;
GRANT ALL ON SCHEMA extensions TO postgres;

-- Add extensions to search path for the current session
SET search_path = public, extensions;

-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  display_name TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Explicitly enable RLS for all public tables (Safety check)
DO $$
DECLARE
    row RECORD;
BEGIN
    FOR row IN SELECT tablename FROM pg_tables WHERE schemaname = 'public'
    LOOP
        EXECUTE 'ALTER TABLE public.' || quote_ident(row.tablename) || ' ENABLE ROW LEVEL SECURITY;';
    END LOOP;
END;
$$;

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', ''), NEW.email);
  RETURN NEW;
END;
$$;

-- Note: In Supabase, you might need to drop the trigger if it already exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create knowledge_bases table
CREATE TABLE IF NOT EXISTS public.knowledge_bases (
    id UUID PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    file_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.knowledge_bases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own knowledge bases" ON public.knowledge_bases FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own knowledge bases" ON public.knowledge_bases FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own knowledge bases" ON public.knowledge_bases FOR DELETE USING (auth.uid() = user_id);

-- Create kb_embeddings table
CREATE TABLE IF NOT EXISTS public.kb_embeddings (
    id UUID PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
    knowledge_base_id UUID REFERENCES public.knowledge_bases(id) ON DELETE CASCADE NOT NULL,
    text_chunk TEXT NOT NULL,
    embedding extensions.VECTOR(768), -- text-embedding-004 is 768 dimensions
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.kb_embeddings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view embeddings of own KBs"
ON public.kb_embeddings FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.knowledge_bases kb
    WHERE kb.id = kb_embeddings.knowledge_base_id
    AND kb.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert embeddings for own KBs"
ON public.kb_embeddings FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.knowledge_bases kb
    WHERE kb.id = kb_embeddings.knowledge_base_id
    AND kb.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete embeddings of own KBs"
ON public.kb_embeddings FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM public.knowledge_bases kb
    WHERE kb.id = kb_embeddings.knowledge_base_id
    AND kb.user_id = auth.uid()
  )
);

-- Create workflows table
CREATE TABLE IF NOT EXISTS public.workflows (
  id UUID PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  nodes JSONB DEFAULT '[]'::jsonb,
  edges JSONB DEFAULT '[]'::jsonb,
  config JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.workflows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own workflows" ON public.workflows FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own workflows" ON public.workflows FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own workflows" ON public.workflows FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own workflows" ON public.workflows FOR DELETE USING (auth.uid() = user_id);

-- Create chat_logs table
CREATE TABLE IF NOT EXISTS public.chat_logs (
  id UUID PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
  workflow_id UUID REFERENCES public.workflows(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'bot')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chat logs" ON public.chat_logs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own chat logs" ON public.chat_logs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own chat logs" ON public.chat_logs FOR DELETE USING (auth.uid() = user_id);

-- Create documents storage bucket (Only run if you have permissions)
-- Note: Buckets are often best created via the Supabase UI.
-- INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false) ON CONFLICT (id) DO NOTHING;

-- Storage Policies for 'documents' bucket
-- Note: Requires storage extensions to be enabled
CREATE POLICY "Users can upload documents" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can view own documents" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete own documents" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS update_workflows_updated_at ON public.workflows;
CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON public.workflows FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function for similarity search
CREATE OR REPLACE FUNCTION public.match_kb_embeddings(
    query_embedding extensions.VECTOR(768),
    match_threshold FLOAT,
    match_count INT,
    knowledge_base_id UUID
)
RETURNS TABLE (
    id UUID,
    text_chunk TEXT,
    similarity FLOAT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
    RETURN QUERY
    SELECT
        kb.id,
        kb.text_chunk,
        1 - (kb.embedding <=> query_embedding) AS similarity
    FROM public.kb_embeddings kb
    WHERE kb.knowledge_base_id = match_kb_embeddings.knowledge_base_id
      AND 1 - (kb.embedding <=> query_embedding) > match_threshold
    ORDER BY kb.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
