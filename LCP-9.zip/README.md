# 🧠 No-Code AI Workflow Builder

It is an **low-code/no-code platform** to visually build, configure, and run intelligent workflows using LLMs, embeddings, knowledge bases, and vector search. Built for fast prototyping and production-ready use-cases.

> ⚡ Drag, Connect, Run — all from your browser.

---

### 🚀 Features

- 🧱 **Drag & Drop Workflow Builder** with React Flow
- 🧠 **LLM Nodes** (Gemini/OpenAI) for prompt-based intelligence
- 📚 **Knowledge Base Nodes** using embeddings + ChromaDB
- 💬 **Built-in AI Chatbot** connected to your workflows
- 🔐 **Secure API Key Handling** with encryption
- 📦 **Supabase** as the backend database
- 📂 Upload & use PDFs for context in workflows
- 📊 Easy saving/loading of workflows

---



## 🧠 Node Types

| Node             | Purpose                                              |
|------------------|------------------------------------------------------|
| User Query       | Entry point – accepts user question                  |
| Knowledge Base   | Upload PDFs, vectorize using embeddings              |
| LLM Engine       | Uses Gemini to generate final responses              |
| Output           | Displays final response in chat                      |

---

## 🖥️ Stack

| Layer        | Tech                               |
|--------------|------------------------------------|
| Frontend     | React + TypeScript + Tailwind CSS  |
| Visual Flow  | React Flow                         |
| Backend      | FastAPI                            |
| Database     | Supabase (PostgreSQL)              |
| Embedding    | Gemini Embeddings / OpenAI         |
| Vector DB    | ChromaDB                           |
| LLM Inference| Gemini 1.5 Pro / Flash             |
| Security     | AES-256 Encryption                 |
| Zustand      | State Management                   |
---

### 📦 Setup Instructions

#### 1. Database Setup (Supabase)
1. Create a new Supabase project.
2. Run the SQL migration script found in `@/Backend/db/migrations/20240216000000_initial_schema.sql` in your Supabase SQL Editor.
3. Enable the `pgvector` extension in your Supabase project (Database -> Extensions -> search for `vector`).
4. **Storage Setup**: Create a new public bucket named `documents` in your Supabase Storage. This is required for saving uploaded PDFs and documents.

#### 2. Backend Setup
1. Navigate to the `Backend` directory: `cd Backend`
2. Create a virtual environment: `python -m venv venv`
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Create a `.env` file based on `.env.example`:
   ```bash
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_service_role_key
   GEMINI_API_KEY=your_gemini_api_key
   OPENAI_API_KEY=your_openai_api_key
   SERP_API_KEY=your_serp_api_key
   ENCRYPTION_KEY=your_32_byte_base64_encryption_key
   ```
6. Run the server: `uvicorn main:app --reload`

#### 3. Frontend Setup
1. Navigate to the `Frontend` directory: `cd Frontend`
2. Install dependencies: `npm install`
3. Create a `.env` file:
   ```bash
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_PUBLISHABLE_KEY=your_supabase_anon_key
   ```
4. Run the development server: `npm run dev`

🔑 Environment Variables
Make sure to create a .env file in server/ with:
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_service_role_key
ENCRYPTION_SECRET_KEY=your_32_byte_key  # Used to encrypt API keys

📖 How It Works

Build Workflows with nodes like:
User Query Node
LLM Node
Knowledge Base Node
Output Node


Connect them visually with edges
Save the workflow to Supabase
Run the workflow using the built-in chatbot
Chat UI uses Gemini + ChromaDB for intelligent answers

🔐 Security

API keys are AES encrypted before storing in Supabase
Decryption only happens at runtime during workflow execution

🧠 Future Plans

🔌 OpenAI + Anthropic + Mistral integration
💾 Vector DB configuration via UI
📜 Prompt templates and memory support
🧩 Node plugin system

