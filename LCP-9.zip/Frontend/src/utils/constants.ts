export const NODE_TYPES = {
  USER_QUERY: "userQuery",
  LLM: "llm",
  KNOWLEDGE_BASE: "knowledgeBase",
  WEB_SEARCH: "webSearch",
  OUTPUT: "output",
} as const;

export const DEFAULT_LLM_CONFIG = {
  model: "google/gemini-2.5-flash",
  temperature: "0.7",
  prompt: "You are a helpful AI assistant. Use provided context and web search results to answer queries accurately.",
  webSearchEnabled: true,
};

export const DEFAULT_KB_CONFIG = {
  embeddingModel: "models/text-embedding-004",
};

export const AVAILABLE_MODELS = [
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash" },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro" },
  { value: "google/gemini-3-flash-preview", label: "Gemini 3 Flash" },
] as const;

export const EMBEDDING_MODELS = [
  { value: "models/text-embedding-004", label: "Gemini text-embedding-004" },
  { value: "text-embedding-3-large", label: "text-embedding-3-large" },
  { value: "text-embedding-3-small", label: "text-embedding-3-small" },
] as const;
