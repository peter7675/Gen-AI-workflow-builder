import type { Node, Edge } from "@xyflow/react";

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

export function validateWorkflow(nodes: Node[], edges: Edge[]): ValidationResult {
  const errors: string[] = [];

  if (nodes.length === 0) {
    errors.push("Workflow must have at least one node.");
    return { valid: false, errors };
  }

  const hasUserQuery = nodes.some((n) => n.type === "userQuery" || n.type === "userQueryNode");
  const hasOutput = nodes.some((n) => n.type === "output" || n.type === "outputNode");
  const hasLLM = nodes.some((n) => n.type === "llm" || n.type === "llmNode");

  if (!hasUserQuery) errors.push("Workflow must include a User Query node.");
  if (!hasLLM) errors.push("Workflow must include an LLM node.");
  if (!hasOutput) errors.push("Workflow must include an Output node.");

  if (edges.length === 0 && nodes.length > 1) {
    errors.push("Nodes must be connected.");
  }

  // Validate LLM node has required config
  const llmNodes = nodes.filter((n) => n.type === "llm" || n.type === "llmNode");
  for (const llm of llmNodes) {
    const config = (llm.data as any)?.config;
    if (!config?.model) {
      errors.push("LLM node must have a model selected.");
    }
  }

  return { valid: errors.length === 0, errors };
}

export function validateStackName(name: string): string | null {
  if (!name.trim()) return "Name is required";
  if (name.length > 100) return "Name must be under 100 characters";
  return null;
}
