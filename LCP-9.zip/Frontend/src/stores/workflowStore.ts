import { create } from "zustand";
import type { Node, Edge, NodeChange, EdgeChange, Connection } from "@xyflow/react";
import { applyNodeChanges, applyEdgeChanges, addEdge } from "@xyflow/react";

export interface NodeData {
  label: string;
  name: string;
  type: string;
  config?: Record<string, any>;
  workflowId?: string;
  [key: string]: any;
}

interface WorkflowStore {
  selectedWorkflowId: string | null;
  workflowName: string;
  workflowDescription: string;
  nodes: Node[];
  edges: Edge[];
  draggedType: string | null;

  setSelectedWorkflowId: (id: string | null) => void;
  setWorkflowName: (name: string) => void;
  setWorkflowDescription: (desc: string) => void;
  setNodes: (nodes: Node[]) => void;
  setEdges: (edges: Edge[]) => void;
  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (connection: Connection) => void;
  addNode: (node: Node) => void;
  removeNode: (id: string) => void;
  removeEdge: (id: string) => void;
  updateNodeConfig: (nodeId: string, config: Record<string, any>) => void;
  setDraggedType: (type: string | null) => void;
  resetWorkflowBuilder: () => void;
}

export const useWorkflowStore = create<WorkflowStore>((set, get) => ({
  selectedWorkflowId: null,
  workflowName: "",
  workflowDescription: "",
  nodes: [],
  edges: [],
  draggedType: null,

  setSelectedWorkflowId: (id) => set({ selectedWorkflowId: id }),
  setWorkflowName: (name) => set({ workflowName: name }),
  setWorkflowDescription: (desc) => set({ workflowDescription: desc }),
  setNodes: (nodes) => set({ nodes }),
  setEdges: (edges) => set({ edges }),
  onNodesChange: (changes) => set({ nodes: applyNodeChanges(changes, get().nodes) }),
  onEdgesChange: (changes) => set({ edges: applyEdgeChanges(changes, get().edges) }),
  onConnect: (connection) => set({ edges: addEdge(connection, get().edges) }),
  addNode: (node) => set({ nodes: [...get().nodes, node] }),
  removeNode: (id) =>
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
    }),
  removeEdge: (id) => set({ edges: get().edges.filter((e) => e.id !== id) }),
  updateNodeConfig: (nodeId, config) =>
    set({
      nodes: get().nodes.map((n) =>
        n.id === nodeId
          ? { ...n, data: { ...n.data, config: { ...(n.data as any).config, ...config } } }
          : n
      ),
    }),
  setDraggedType: (type) => set({ draggedType: type }),
  resetWorkflowBuilder: () =>
    set({
      selectedWorkflowId: null,
      workflowName: "",
      workflowDescription: "",
      nodes: [],
      edges: [],
      draggedType: null,
    }),
}));
