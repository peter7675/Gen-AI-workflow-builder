import { useNavigate, useLocation } from "react-router-dom";
import { CircleDot, Save, LogOut, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface HeaderProps {
  onSave?: () => void;
}

const Header = ({ onSave }: HeaderProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile, signOut } = useAuth();
  const isBuilder = location.pathname.startsWith("/builder");

  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  const initials = profile?.display_name
    ? profile.display_name.charAt(0).toUpperCase()
    : profile?.email?.charAt(0).toUpperCase() || "U";

  return (
    <header className="flex h-14 items-center justify-between border-b px-4">
      <div
        className="flex cursor-pointer items-center gap-2"
        onClick={() => navigate("/stacks")}
      >
        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
  
        <div className="w-6 h-6 border-2 border-white rounded-full flex items-center justify-center">
         <span className="text-white font-bold text-[10px] leading-none lowercase tracking-tighter">
               ai
          </span>
        </div>
        </div>
        <span className="text-sm font-semibold">GenAI Stack</span>
      </div>

      <div className="flex items-center gap-3">
        {isBuilder && onSave && (
          <Button variant="outline" size="sm" className="gap-1.5" onClick={onSave}>
            <Save className="h-3.5 w-3.5" />
            Save
          </Button>
        )}
        <Button variant="ghost" size="sm" className="gap-1.5" onClick={handleLogout}>
          <LogOut className="h-3.5 w-3.5" />
          Logout
        </Button>
        <Popover>
          <PopoverTrigger asChild>
            <button className="focus:outline-none">
              <Avatar className="h-8 w-8 bg-primary cursor-pointer">
                <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-64" align="end">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 bg-primary">
                  <AvatarFallback className="bg-primary text-sm text-primary-foreground">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{profile?.display_name || "User"}</p>
                  <p className="text-xs text-muted-foreground truncate">{profile?.email || ""}</p>
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </header>
  );
};

export default Header;
