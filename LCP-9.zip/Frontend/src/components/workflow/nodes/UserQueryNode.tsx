import React, { useEffect, useState } from "react";
import { Handle, Position } from "@xyflow/react";
import { MessageSquare, Settings, X } from "lucide-react";
import { useWorkflowStore } from "@/stores/workflowStore";
import type { NodeData } from "@/stores/workflowStore";

export const UserQueryNode = ({ id, selected, data }: { id: string; selected?: boolean; data: NodeData }) => {
  const updateNodeConfig = useWorkflowStore((state) => state.updateNodeConfig);
  const removeNode = useWorkflowStore((state) => state.removeNode);
  const [query, setQuery] = useState(
    data.config?.query || "Write your query here"
  );

  useEffect(() => {
    updateNodeConfig(id, {
      query: query,
      name: data.name || "UserQuery",
    });
  }, [query, id, updateNodeConfig, data.name]);

  return (
    <div className="w-56 rounded-lg border bg-card shadow-sm">
      <div className="flex items-center justify-between rounded-t-lg bg-primary/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">User Query</span>
        </div>
        <Settings className="w-4 h-4 text-gray-400 ml-auto" />
        <button onClick={() => removeNode(id)} className="rounded p-0.5 hover:bg-destructive/10">
          <X className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
        </button>
      </div>

      <div className="space-y-3 p-3">
        <div>
          <label className="text-xs text-gray-600">Entry point for queries</label>
        </div>
        <div className="space-y-1">
          <label className="text-xs font-medium">User Query</label>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full p-2 border rounded text-sm resize-none"
            rows={3}
          />
        </div>
      </div>
      
      <Handle
        type="source"
        position={Position.Right}
        id="source"
        className="w-4 h-4 bg-orange-500"
        style={{
          position: "absolute",
          width: "8px",
          height: "8px",
          backgroundColor: "#F58421",
          border: "1px solid #64748b",
        }}
      />
    </div>
  );
};

export default UserQueryNode;
