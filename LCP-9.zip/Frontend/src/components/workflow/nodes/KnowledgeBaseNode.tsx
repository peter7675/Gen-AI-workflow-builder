import React, { useState, useEffect, useCallback } from "react";
import { Handle, Position } from "@xyflow/react";
import { Database, Upload, Settings, Trash2, X, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { useWorkflowStore } from "@/stores/workflowStore";
import type { NodeData } from "@/stores/workflowStore";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import * as pdfjsLib from "pdfjs-dist";

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

type ProcessingStatus = "idle" | "uploading" | "processing" | "done" | "error";

async function extractTextFromFile(file: File): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase();
  if (ext === "pdf") {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const pages: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      pages.push(content.items.map((item: any) => item.str).join(" "));
    }
    return pages.join("\n\n");
  }
  return await file.text();
}

function chunkText(text: string, chunkSize = 1000, overlap = 200): string[] {
  const chunks: string[] = [];
  let start = 0;
  while (start < text.length) {
    let end = Math.min(start + chunkSize, text.length);
    if (end < text.length) {
      const bp = Math.max(text.lastIndexOf(".", end), text.lastIndexOf("\n", end));
      if (bp > start + chunkSize / 2) end = bp + 1;
    }
    const chunk = text.slice(start, end).trim();
    if (chunk.length > 10) chunks.push(chunk);
    start = end - overlap;
    if (start >= text.length) break;
  }
  return chunks;
}

async function generateEmbedding(text: string, apiKey: string, model: string): Promise<number[]> {
  const resp = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/${model}:embedContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, content: { parts: [{ text }] } }),
    }
  );
  if (!resp.ok) throw new Error(`Embedding API error ${resp.status}`);
  const data = await resp.json();
  return data.embedding?.values || [];
}

export const KnowledgeBaseNode = ({ id, selected, data }: { id: string; selected?: boolean; data: NodeData }) => {
  const updateNodeConfig = useWorkflowStore((state) => state.updateNodeConfig);
  const removeNode = useWorkflowStore((state) => state.removeNode);
  const { user } = useAuth();

  const [embedding, setEmbedding] = useState(data.config?.embeddingModel || "models/text-embedding-004");
  const [apiKey, setApiKey] = useState(data.config?.apiKey || "");
  const [uploadedFileName, setUploadedFileName] = useState(data.config?.uploadedFileName || "");
  const [knowledgeBaseId, setKnowledgeBaseId] = useState(data.config?.knowledgeBaseId || "");
  const [status, setStatus] = useState<ProcessingStatus>("idle");
  const [statusMsg, setStatusMsg] = useState("");
  const [chunksStored, setChunksStored] = useState(data.config?.chunksStored || 0);

  useEffect(() => {
    updateNodeConfig(id, {
      embeddingModel: embedding, apiKey, uploadedFileName, knowledgeBaseId, chunksStored,
      name: data.name || "KnowledgeBase",
    });
  }, [embedding, apiKey, uploadedFileName, knowledgeBaseId, chunksStored, id, updateNodeConfig, data.name]);

  useEffect(() => {
    if (knowledgeBaseId && chunksStored > 0 && status === "idle") {
      setStatus("done");
      setStatusMsg(`${chunksStored} chunks stored`);
    }
  }, []);

  const processDocument = useCallback(async (file: File) => {
    if (!user?.id) { toast.error("Please sign in first"); return; }
    if (!apiKey) { toast.error("Please enter your Gemini API Key first"); return; }

    try {
      setStatus("uploading");
      setStatusMsg("Extracting text...");

      const text = await extractTextFromFile(file);
      if (!text || text.length < 10) throw new Error("Could not extract readable text.");

      setStatusMsg("Uploading file...");
      const filePath = `${user.id}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage.from("documents").upload(filePath, file);
      if (uploadError) throw new Error(`Upload failed: ${uploadError.message}`);

      const { data: kbData, error: kbError } = await supabase
        .from("knowledge_bases")
        .insert({ name: file.name, file_url: filePath, user_id: user.id })
        .select().single();
      if (kbError || !kbData) throw new Error(`KB creation failed: ${kbError?.message}`);

      const kbId = kbData.id;
      setKnowledgeBaseId(kbId);

      // Chunk + embed + store entirely client-side
      setStatus("processing");
      const chunks = chunkText(text);
      let stored = 0;

      for (let i = 0; i < chunks.length; i++) {
        setStatusMsg(`Embedding chunk ${i + 1}/${chunks.length}...`);
        const emb = await generateEmbedding(chunks[i], apiKey, embedding);
        if (emb.length === 0) continue;

        const { error: insertError } = await supabase.from("kb_embeddings").insert({
          knowledge_base_id: kbId,
          text_chunk: chunks[i],
          embedding: `[${emb.join(",")}]`,
        });
        if (!insertError) stored++;
        if (i < chunks.length - 1) await new Promise((r) => setTimeout(r, 250));
      }

      setChunksStored(stored);
      setStatus("done");
      setStatusMsg(`${stored} chunks stored`);
      toast.success(`Document processed: ${stored} chunks embedded`);
    } catch (err: any) {
      console.error("Document processing error:", err);
      setStatus("error");
      setStatusMsg(err.message || "Processing failed");
      toast.error(err.message || "Document processing failed");
    }
  }, [user, apiKey, embedding]);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) { setUploadedFileName(file.name); processDocument(file); }
  }, [processDocument]);

  const handleDeleteFile = useCallback(async () => {
    if (knowledgeBaseId) {
      await supabase.from("kb_embeddings").delete().eq("knowledge_base_id", knowledgeBaseId);
      await supabase.from("knowledge_bases").delete().eq("id", knowledgeBaseId);
    }
    setUploadedFileName(""); setKnowledgeBaseId(""); setChunksStored(0);
    setStatus("idle"); setStatusMsg("");
    updateNodeConfig(id, { uploadedFile: null, uploadedFileName: "", knowledgeBaseId: "", chunksStored: 0, name: "KnowledgeBase" });
  }, [id, knowledgeBaseId, updateNodeConfig]);

  const statusIcon = () => {
    switch (status) {
      case "uploading": case "processing":
        return <Loader2 className="w-4 h-4 animate-spin text-primary" />;
      case "done": return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "error": return <AlertCircle className="w-4 h-4 text-destructive" />;
      default: return null;
    }
  };

  return (
    <div className="w-56 rounded-lg border bg-card shadow-sm">
      <div className="flex items-center justify-between rounded-t-lg bg-primary/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">Knowledge Base</span>
        </div>
        <Settings className="w-4 h-4 text-muted-foreground ml-auto" />
        <button onClick={() => removeNode(id)} className="rounded p-0.5 hover:bg-destructive/10">
          <X className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
        </button>
      </div>

      <Handle type="target" position={Position.Left} id="target"
        style={{ width: "8px", height: "8px", backgroundColor: "#4FF02F", border: "1px solid #64748b" }} />

      <div className="space-y-3 p-3">
        <label className="text-xs text-muted-foreground">Upload documents for RAG retrieval</label>

        <div>
          <label className="text-xs font-medium">Gemini API Key</label>
          <input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm bg-background" placeholder="API Key (required)" />
        </div>

        <div>
          <label className="text-xs font-medium">File for Knowledge Base</label>
          {uploadedFileName ? (
            <div className="mt-1 p-3 border-2 border-dashed border-green-500/30 rounded bg-green-500/5 flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                {statusIcon()}
                <div className="min-w-0">
                  <span className="text-sm font-medium block truncate">{uploadedFileName}</span>
                  {statusMsg && <span className={`text-xs block ${status === "error" ? "text-destructive" : "text-muted-foreground"}`}>{statusMsg}</span>}
                </div>
              </div>
              <button onClick={handleDeleteFile} className="p-1 hover:bg-destructive/10 rounded transition-colors flex-shrink-0" title="Delete file">
                <Trash2 className="w-4 h-4 text-destructive" />
              </button>
            </div>
          ) : (
            <div className="mt-1 p-3 border-2 border-dashed border-border rounded text-center cursor-pointer relative hover:border-primary/50 transition-colors">
              <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={handleFileChange} accept=".pdf,.txt,.docx" />
              <Upload className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
              <span className="text-xs text-muted-foreground">Upload File</span>
            </div>
          )}
        </div>

        <div>
          <label className="text-xs font-medium">Embedding Model</label>
          <select value={embedding} onChange={(e) => setEmbedding(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm bg-background">
            <option value="models/text-embedding-004">Gemini (text-embedding-004)</option>
          </select>
        </div>
      </div>

      <Handle type="source" position={Position.Right} id="source"
        style={{ width: "8px", height: "8px", backgroundColor: "#F58421", border: "1px solid #64748b" }} />
    </div>
  );
};

export default KnowledgeBaseNode;
