import React, { useState, useEffect } from "react";
import { Handle, Position } from "@xyflow/react";
import { Brain, Settings, X } from "lucide-react";
import type { NodeData } from "@/stores/workflowStore";
import { useWorkflowStore } from "@/stores/workflowStore";
import { AVAILABLE_MODELS } from "@/utils/constants";

export const LLMNode = ({ id, selected, data }: { id: string; selected?: boolean; data: NodeData }) => {
  const updateNodeConfig = useWorkflowStore((state) => state.updateNodeConfig);
  const removeNode = useWorkflowStore((state) => state.removeNode);

  const [model, setModel] = useState(data.config?.model || "google/gemini-2.5-flash");
  const [apiKey, setApiKey] = useState(data.config?.apiKey || "");
  const [serpApi, setSerpApi] = useState(data.config?.serpApi || "");
  const [temperature, setTemperature] = useState(data.config?.temperature || "0.7");
  const [webSearch, setWebSearch] = useState(data.config?.webSearchEnabled ?? true);
  const [prompt, setPrompt] = useState(data.config?.prompt || "You are a helpful AI assistant. Use provided context and web search results to answer queries accurately.");

  useEffect(() => {
    updateNodeConfig(id, {
      model,
      apiKey,
      serpApi,
      temperature,
      webSearchEnabled: webSearch,
      prompt,
      name: data.name || "LLMEngine",
    });
  }, [model, apiKey, serpApi, temperature, webSearch, prompt, id, updateNodeConfig, data.name]);

  return (
    <div className="w-56 rounded-lg border bg-card shadow-sm">
      <div className="flex items-center justify-between rounded-t-lg bg-primary/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <Brain className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">LLM Engine</span>
        </div>
        <Settings className="w-4 h-4 text-muted-foreground ml-auto" />
        <button onClick={() => removeNode(id)} className="rounded p-0.5 hover:bg-destructive/10">
          <X className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
        </button>
      </div>

      <Handle
        type="target"
        position={Position.Left}
        id="context"
        style={{ top: "55%", width: "8px", height: "8px", backgroundColor: "#4FF02F", border: "1px solid #64748b" }}
      />
      <Handle
        type="target"
        position={Position.Left}
        id="query"
        style={{ top: "65%", width: "8px", height: "8px", backgroundColor: "#4FF02F", border: "1px solid #64748b" }}
      />

      <div className="space-y-3 p-3">
        <div>
          <label className="text-xs text-muted-foreground">Run a query with LLM</label>
        </div>
        <div>
          <label className="text-xs font-medium">Model</label>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm bg-background"
          >
            {AVAILABLE_MODELS.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium">API Key</label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm"
            placeholder="API Key"
          />
        </div>
        <div>
          <label className="text-xs font-medium">System Prompt</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm resize-y bg-background"
            rows={3}
            placeholder="Enter system prompt..."
          />
          <div className="mt-1 p-2 border rounded text-sm bg-muted">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs">CONTEXT</span>
              <span className="text-xs text-muted-foreground">(context)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs">User Query</span>
              <span className="text-xs text-muted-foreground">(query)</span>
            </div>
          </div>
        </div>
        <div>
          <label className="text-xs font-medium">Temperature</label>
          <input
            type="text"
            value={temperature}
            onChange={(e) => {
              const val = e.target.value;
              if (val === "" || (parseFloat(val) >= 0 && parseFloat(val) <= 1 && !isNaN(parseFloat(val)))) {
                setTemperature(val);
              }
            }}
            className="w-full mt-1 p-2 border rounded text-sm bg-background"
          />
        </div>
        <div className="flex items-center justify-between">
          <label className="text-xs font-medium">Web Search</label>
          <button
            type="button"
            aria-pressed={webSearch}
            onClick={() => setWebSearch((prev) => !prev)}
            className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
              webSearch ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}
          >
            {webSearch ? "ON" : "OFF"}
          </button>
        </div>
        <div>
          <label className="text-xs font-medium">SERP API</label>
          <input
            type="password"
            value={serpApi}
            onChange={(e) => setSerpApi(e.target.value)}
            className="w-full mt-1 p-2 border rounded text-sm"
            placeholder="API Key"
          />
        </div>
      </div>

      <Handle
        type="source"
        position={Position.Right}
        id="source"
        style={{ width: "8px", height: "8px", backgroundColor: "#F58421", border: "1px solid #64748b" }}
      />
    </div>
  );
};

export default LLMNode;