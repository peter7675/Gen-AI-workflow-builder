import React from "react";
import { Handle, Position } from "@xyflow/react";
import { FileOutput, Settings, X } from "lucide-react";
import { useWorkflowStore } from "@/stores/workflowStore";
import type { NodeData } from "@/stores/workflowStore";

export const OutputNode = ({ id, selected, data }: { id: string; selected?: boolean; data: NodeData }) => {
  const removeNode = useWorkflowStore((state) => state.removeNode);
  const outputText = typeof data?.config?.output === "string"
    ? data.config.output
    : "Output will be generated based on query";
  
  return (
    <div className="w-56 rounded-lg border bg-card shadow-sm">
      <div className="flex items-center justify-between rounded-t-lg bg-primary/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <FileOutput className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">Output</span>
        </div>
        <Settings className="w-4 h-4 text-gray-400 ml-auto" />
        <button onClick={() => removeNode(id)} className="rounded p-0.5 hover:bg-destructive/10">
          <X className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
        </button>
      </div>

      <Handle
        type="target"
        position={Position.Left}
        id="target"
        className="w-4 h-4 bg-gray-400"
        style={{
          position: "absolute",
          width: "8px",
          height: "8px",
          backgroundColor: "#4FF02F",
          border: "1px solid #64748b",
        }}
      />
      
      <div className="space-y-3 p-3">
        <div>
          <label className="text-xs text-gray-600">
            Output of the result nodes as text
          </label>
        </div>
        <div>
          <label className="text-xs font-medium">Output Text</label>
          <div className="mt-1 p-2 border rounded text-sm bg-gray-50 text-gray-600 h-20 overflow-y-auto break-words">
            {outputText}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OutputNode;
