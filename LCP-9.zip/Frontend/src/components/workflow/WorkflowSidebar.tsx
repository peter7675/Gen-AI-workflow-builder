import { GripVertical, MessageSquare, Brain, Database, ArrowRightFromLine, Globe, Image } from "lucide-react";
import { ComponentItem } from "@/types/stack";

const components: ComponentItem[] = [
  { type: "userQuery", label: "User Query", icon: "userQuery" },
  { type: "llm", label: "LLM (OpenAI)", icon: "llm" },
  { type: "knowledgeBase", label: "Knowledge Base", icon: "knowledgeBase" },
  { type: "webSearch", label: "Web Search", icon: "webSearch" },
  { type: "output", label: "Output", icon: "output" },
];

const iconMap: Record<string, React.ReactNode> = {
  userQuery: <MessageSquare className="h-4 w-4" />,
  llm: <Brain className="h-4 w-4" />,
  knowledgeBase: <Database className="h-4 w-4" />,
  webSearch: <Globe className="h-4 w-4" />,
  output: <ArrowRightFromLine className="h-4 w-4" />,
};

interface WorkflowSidebarProps {
  stackName: string;
  onRename: () => void;
}

const WorkflowSidebar = ({ stackName, onRename }: WorkflowSidebarProps) => {
  const onDragStart = (event: React.DragEvent, componentType: string) => {
    event.dataTransfer.setData("application/reactflow", componentType);
    event.dataTransfer.effectAllowed = "move";
  };

  return (
    <aside className="flex w-44 flex-col border-r bg-background">
      <div className="flex items-center gap-2 border-b px-3 py-3">
        <span className="text-sm font-medium truncate">{stackName}</span>
        <button
          onClick={onRename}
          className="shrink-0 rounded p-0.5 hover:bg-muted"
        >
          <Image className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      </div>

      <div className="px-3 py-3">
        <p className="mb-2 text-xs font-medium text-muted-foreground">
          Components
        </p>
        <div className="space-y-1">
          {components.map((comp) => (
            <div
              key={comp.type}
              draggable
              onDragStart={(e) => onDragStart(e, comp.type)}
              className="flex cursor-grab items-center justify-between rounded-md border px-2.5 py-2 text-sm transition-colors hover:bg-muted active:cursor-grabbing"
            >
              <div className="flex items-center gap-2">
                {iconMap[comp.icon]}
                <span className="text-xs">{comp.label}</span>
              </div>
              <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};

export default WorkflowSidebar;
