import { useCallback, useRef, useState } from "react";
import {
  ReactFlow,
  Controls,
  Background,
  BackgroundVariant,
  MiniMap,
  ReactFlowProvider,
  type Node,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Play, MessageCircle, Workflow, Save, Lock, Unlock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import UserQueryNode from "./nodes/UserQueryNode";
import LLMNode from "./nodes/LLMNode";
import KnowledgeBaseNode from "./nodes/KnowledgeBaseNode";
import OutputNode from "./nodes/OutputNode";
import WebSearchNode from "./nodes/WebSearchNode";
import ChatDialog from "../ChatDialog";
import ExecutionLogsPanel, { type LogEntry } from "./ExecutionLogsPanel";
import { useWorkflowStore, NodeData } from "@/stores/workflowStore";
import { DEFAULT_LLM_CONFIG, DEFAULT_KB_CONFIG } from "@/utils/constants";
import { validateWorkflow } from "@/utils/validation";
import { toast } from "sonner";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { supabase } from "@/integrations/supabase/client";

const nodeTypes = {
  userQuery: UserQueryNode,
  llm: LLMNode,
  knowledgeBase: KnowledgeBaseNode,
  output: OutputNode,
  webSearch: WebSearchNode,
  userQueryNode: UserQueryNode,
  llmNode: LLMNode,
  knowledgeBaseNode: KnowledgeBaseNode,
  outputNode: OutputNode,
  webSearchNode: WebSearchNode,
};

interface WorkflowCanvasProps {
  workflowId: string;
  onSave: () => void;
}

const WorkflowCanvasInner = ({ workflowId, onSave }: WorkflowCanvasProps) => {
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [interactive, setInteractive] = useState(true);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logsVisible, setLogsVisible] = useState(false);

  const { nodes, edges, onNodesChange, onEdgesChange, onConnect, addNode } = useWorkflowStore();
  const { user, loading: authLoading, session } = useAuth();

  const addLog = useCallback((level: LogEntry["level"], step: string, message: string) => {
    setLogs((prev) => [
      ...prev,
      { id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`, timestamp: new Date().toISOString(), level, step, message },
    ]);
  }, []);

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();
      const type = event.dataTransfer.getData("application/reactflow");
      if (!type || !reactFlowInstance) return;

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const nodeId = `node_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      let data: NodeData = { label: type, name: type, type };

      if (type === "llm") {
        data = { label: "LLM Engine", name: "LLMEngine", type: "llmNode", config: { ...DEFAULT_LLM_CONFIG } };
      } else if (type === "knowledgeBase") {
        data = { label: "Knowledge Base", name: "KnowledgeBase", type: "knowledgeBaseNode", config: { ...DEFAULT_KB_CONFIG } };
      } else if (type === "userQuery") {
        data = { label: "User Query", name: "UserQuery", type: "userQueryNode", config: { query: "Write your query here" } };
      } else if (type === "output") {
        data = { label: "Output", name: "Output", type: "outputNode", config: { output: "" } };
      } else if (type === "webSearch") {
        data = { label: "Web Search", name: "WebSearch", type: "webSearchNode", config: {} };
      }

      const newNode: Node = { id: nodeId, type: data.type, position, data };
      addNode(newNode);
    },
    [reactFlowInstance, addNode]
  );

  const handleRunWorkflow = async () => {
    if (!user) {
      toast.error("Please sign in to execute workflows");
      return;
    }
    if (authLoading) {
      toast.error("Authentication loading, please wait");
      return;
    }

    setLogsVisible(true);
    addLog("info", "Workflow", "Starting workflow execution...");

    // Validate workflow
    const result = validateWorkflow(nodes, edges);
    if (!result.valid) {
      result.errors.forEach((e) => {
        toast.error(e);
        addLog("error", "Validation", e);
      });
      return;
    }
    addLog("success", "Validation", "Workflow is valid");

    // Find the UserQuery node
    const userQueryNode = nodes.find(
      (node) => node.type === "userQueryNode" || node.type === "userQuery"
    );
    if (!userQueryNode) {
      toast.error("Workflow must include a User Query node");
      addLog("error", "Validation", "Missing User Query node");
      return;
    }

    const nodeData = userQueryNode.data as NodeData;
    const userQuery = nodeData?.config?.query || "Default query";
    addLog("info", "UserQuery", `Query: "${userQuery.slice(0, 100)}${userQuery.length > 100 ? "..." : ""}"`);

    // Check KB node
    const kbNode = nodes.find((n) => n.type === "knowledgeBaseNode" || n.type === "knowledgeBase");
    if (kbNode) {
      const kbData = kbNode.data as NodeData;
      if (kbData.config?.knowledgeBaseId) {
        addLog("info", "KnowledgeBase", `KB ID: ${kbData.config.knowledgeBaseId}, Chunks: ${kbData.config.chunksStored || 0}`);
      } else {
        addLog("warn", "KnowledgeBase", "No document uploaded or processed yet");
      }
    }

    // Check LLM node
    const llmNode = nodes.find((n) => n.type === "llmNode" || n.type === "llm");
    if (llmNode) {
      const llmData = llmNode.data as NodeData;
      addLog("info", "LLM", `Model: ${llmData.config?.model || "default"}, Temp: ${llmData.config?.temperature || 0.7}`);
    }

    try {
      // Auto-save workflow
      addLog("info", "Workflow", "Auto-saving workflow...");
      const { workflowName, workflowDescription } = useWorkflowStore.getState();
      const { error: saveError } = await supabase
        .from("workflows")
        .update({
          name: workflowName || "Untitled Workflow",
          description: workflowDescription || "",
          nodes: nodes as any,
          edges: edges as any,
        })
        .eq("id", workflowId);

      if (saveError) {
        addLog("error", "Save", `Failed: ${saveError.message}`);
        toast.error("Failed to save workflow before execution");
        return;
      }
      addLog("success", "Save", "Workflow saved");

      // Execute via the chat edge function
      addLog("info", "Execution", "Calling AI backend...");
      const CHAT_URL = `http://localhost:8000/api/run/execute`;
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers,
        body: JSON.stringify({ 
          workflow_id: workflowId,
          user_query: userQuery 
        }),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        addLog("error", "Execution", `HTTP ${resp.status}: ${errData.detail || "Unknown error"}`);
        throw new Error(errData.detail || `Execution failed (${resp.status})`);
      }

      const result = await resp.json();
      const finalResponse = result.workflow_response?.final_response || "No response generated";
      
      // Update the Output node with the result
      const outputNode = nodes.find(
        (node) => node.type === "outputNode" || node.type === "output"
      );
      if (outputNode && finalResponse) {
        const { updateNodeConfig } = useWorkflowStore.getState();
        updateNodeConfig(outputNode.id, { output: finalResponse });
        addLog("success", "Output", `Response received (${finalResponse.length} chars)`);
      }

      addLog("success", "Workflow", "Execution completed successfully");
      toast.success("Workflow executed successfully!");
    } catch (error: any) {
      console.error("Workflow execution error:", error);
      addLog("error", "Workflow", `Failed: ${error.message || "Unknown error"}`);
      toast.error(`Execution failed: ${error.message || "Unknown error"}`);
    }
  };

  const handleSaveWorkflow = () => {
    const result = validateWorkflow(nodes, edges);
    if (!result.valid) {
      result.errors.forEach((e) => toast.error(e));
      return;
    }
    onSave();
    toast.success("Workflow saved successfully!");
  };

  return (
    <div className="relative flex-1" ref={reactFlowWrapper}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onInit={setReactFlowInstance}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        fitView={false}
        defaultViewport={{ x: 0, y: 0, zoom: 1 }}
        className="bg-canvas-bg"
        deleteKeyCode="Delete"
        nodesDraggable={interactive}
        nodesConnectable={interactive}
        elementsSelectable={interactive}
      >
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="hsl(var(--canvas-dot))" />
        <Controls showInteractive={false} />
        <MiniMap
          nodeStrokeWidth={3}
          zoomable
          pannable
          className="!bg-card !border-border"
        />
      </ReactFlow>

      {nodes.length === 0 && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
            <Workflow className="h-7 w-7 text-primary" />
          </div>
          <p className="text-sm text-muted-foreground">Drag & drop to get started</p>
        </div>
      )}

      <div className="absolute bottom-6 right-6 flex flex-col gap-2" style={{ zIndex: 30 }}>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant={interactive ? "outline" : "secondary"}
                className="h-9 w-9 rounded-full shadow-lg"
                onClick={() => setInteractive((prev) => !prev)}
              >
                {interactive ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{interactive ? "Lock Canvas" : "Unlock Canvas"}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button size="icon" className="h-11 w-11 rounded-full shadow-lg" onClick={handleRunWorkflow}>
                <Play className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Run Workflow</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="secondary"
                className="h-11 w-11 rounded-full border shadow-lg"
                onClick={() => setChatOpen(true)}
              >
                <MessageCircle className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>GenAI Stack Chatbot</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <ExecutionLogsPanel
        logs={logs}
        visible={logsVisible}
        onClear={() => setLogs([])}
        onToggle={() => setLogsVisible((v) => !v)}
      />

      <ChatDialog open={chatOpen} onOpenChange={setChatOpen} workflowId={workflowId} />
    </div>
  );
};

const WorkflowCanvas = (props: WorkflowCanvasProps) => (
  <ReactFlowProvider>
    <WorkflowCanvasInner {...props} />
  </ReactFlowProvider>
);

export default WorkflowCanvas;
