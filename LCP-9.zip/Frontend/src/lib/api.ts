const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";

export async function processDocument(file: File, geminiKey: string) {
  const form = new FormData();
  form.append("file", file);
  form.append("gemini_key", geminiKey);

  const res = await fetch(`${BACKEND_URL}/process-document`, {
    method: "POST",
    body: form,
  });
  return res.json();
}

export async function executeWorkflow(payload: any) {
  const res = await fetch(`${BACKEND_URL}/execute-workflow`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return res.json();
}
