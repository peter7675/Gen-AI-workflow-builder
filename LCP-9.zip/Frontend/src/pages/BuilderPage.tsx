import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState, useCallback } from "react";
import Header from "@/components/Header";
import WorkflowSidebar from "@/components/workflow/WorkflowSidebar";
import WorkflowCanvas from "@/components/workflow/WorkflowCanvas";
import { useWorkflow } from "@/hooks/useWorkflow";
import { useWorkflowStore } from "@/stores/workflowStore";
import { toast } from "sonner";

const BuilderPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getWorkflow, updateWorkflow } = useWorkflow();
  const { nodes, edges, setNodes, setEdges, setWorkflowName, setWorkflowDescription, setSelectedWorkflowId, workflowName, resetWorkflowBuilder } = useWorkflowStore();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!id) { navigate("/stacks"); return; }
    resetWorkflowBuilder();
    setSelectedWorkflowId(id);

    getWorkflow(id).then((w) => {
      if (!w) { navigate("/stacks"); return; }
      setWorkflowName(w.name);
      setWorkflowDescription(w.description);
      setNodes(w.nodes || []);
      setEdges(w.edges || []);
      setLoaded(true);
    });
  }, [id]);

  const handleSave = useCallback(async () => {
    if (!id) return;
    const ok = await updateWorkflow(id, { nodes, edges });
    if (ok) toast.success("Workflow saved!");
  }, [id, nodes, edges, updateWorkflow]);

  if (!loaded) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-muted-foreground">Loading workflow...</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col">
      <Header onSave={handleSave} />
      <div className="flex flex-1 overflow-hidden">
        <WorkflowSidebar stackName={workflowName || "Untitled"} onRename={() => {}} />
        <WorkflowCanvas workflowId={id!} onSave={handleSave} />
      </div>
    </div>
  );
};

export default BuilderPage;
