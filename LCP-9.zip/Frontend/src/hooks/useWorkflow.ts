import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import type { Json } from "@/integrations/supabase/types";

export interface Workflow {
  id: string;
  user_id: string;
  name: string;
  description: string;
  nodes: any[];
  edges: any[];
  config: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export function useWorkflow() {
  const { user } = useAuth();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchWorkflows = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("workflows")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      setWorkflows(
        (data || []).map((w: any) => ({
          ...w,
          nodes: Array.isArray(w.nodes) ? w.nodes : [],
          edges: Array.isArray(w.edges) ? w.edges : [],
          config: typeof w.config === "object" && w.config !== null ? w.config : {},
        }))
      );
    } catch (err: any) {
      toast.error("Failed to load workflows");
    } finally {
      setLoading(false);
    }
  }, [user]);

  const createWorkflow = useCallback(
    async (name: string, description: string) => {
      if (!user) return null;
      const { data, error } = await supabase
        .from("workflows")
        .insert({ user_id: user.id, name, description })
        .select()
        .single();
      if (error) {
        toast.error("Failed to create workflow");
        return null;
      }
      const workflow: Workflow = {
        ...data,
        nodes: [],
        edges: [],
        config: {},
      };
      setWorkflows((prev) => [workflow, ...prev]);
      return workflow;
    },
    [user]
  );

  const updateWorkflow = useCallback(
    async (id: string, updates: Partial<Pick<Workflow, "name" | "description" | "nodes" | "edges" | "config">>) => {
      const payload: Record<string, any> = {};
      if (updates.name !== undefined) payload.name = updates.name;
      if (updates.description !== undefined) payload.description = updates.description;
      if (updates.nodes !== undefined) payload.nodes = updates.nodes as unknown as Json;
      if (updates.edges !== undefined) payload.edges = updates.edges as unknown as Json;
      if (updates.config !== undefined) payload.config = updates.config as unknown as Json;

      const { error } = await supabase.from("workflows").update(payload).eq("id", id);
      if (error) {
        toast.error("Failed to save workflow");
        return false;
      }
      setWorkflows((prev) =>
        prev.map((w) => (w.id === id ? { ...w, ...updates } : w))
      );
      return true;
    },
    []
  );

  const deleteWorkflow = useCallback(async (id: string) => {
    const { error } = await supabase.from("workflows").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete workflow");
      return false;
    }
    setWorkflows((prev) => prev.filter((w) => w.id !== id));
    return true;
  }, []);

  const getWorkflow = useCallback(async (id: string): Promise<Workflow | null> => {
    const { data, error } = await supabase.from("workflows").select("*").eq("id", id).single();
    if (error) return null;
    return {
      ...data,
      nodes: Array.isArray(data.nodes) ? data.nodes : [],
      edges: Array.isArray(data.edges) ? data.edges : [],
      config: typeof data.config === "object" && data.config !== null ? data.config : {},
    };
  }, []);

  return { workflows, loading, fetchWorkflows, createWorkflow, updateWorkflow, deleteWorkflow, getWorkflow };
}
